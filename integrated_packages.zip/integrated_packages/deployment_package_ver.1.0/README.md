this is a placeholder file used for committing the source_code directory to
the git repo
