#ifndef AUTH_SEEDER_H
#define AUTH_SEEDER_H

void seedAuth();

#endif // AUTH_SEEDER_H
