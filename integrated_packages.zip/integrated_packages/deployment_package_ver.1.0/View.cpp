#include "MainApp.h"
#include "View.h"

View::View(MainApp *app) : parent(app) {}

