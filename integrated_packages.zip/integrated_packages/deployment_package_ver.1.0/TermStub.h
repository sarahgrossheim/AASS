#ifndef TERM_TEST_H
#define TERM_TEST_H

int runTermTest();

#endif // TERM_TEST_H

